import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService service;
    private Contact c1;

    @BeforeEach
    public void setup() {
        service = new ContactService();
        c1 = new Contact("c1", "John", "Doe", "1234567890", "123 A St");
    }

    @Test
    public void addAndGetContact() {
        service.addContact(c1);
        Contact fetched = service.getContact("c1");
        assertNotNull(fetched);
        assertEquals("John", fetched.getFirstName());
    }

    @Test
    public void addDuplicateThrows() {
        service.addContact(c1);
        Contact dup = new Contact("c1", "J", "D", "0987654321", "B");
        assertThrows(IllegalArgumentException.class, () -> service.addContact(dup));
    }

    @Test
    public void deleteContact() {
        service.addContact(c1);
        service.deleteContact("c1");
        assertNull(service.getContact("c1"));
    }

    @Test
    public void updateFields() {
        service.addContact(c1);
        service.updateFirstName("c1", "Alice");
        service.updateLastName("c1", "Wonder");
        service.updatePhone("c1", "1112223333");
        service.updateAddress("c1", "New Addr");
        Contact updated = service.getContact("c1");
        assertEquals("Alice", updated.getFirstName());
        assertEquals("Wonder", updated.getLastName());
        assertEquals("1112223333", updated.getPhone());
        assertEquals("New Addr", updated.getAddress());
    }

    @Test
    public void updateNonExistingThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("x", "A"));
    }

    @Test
    public void deleteNullIdThrowsArg() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact(null));
    }

    @Test
    public void addNullContactThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }
}
