import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) throw new IllegalArgumentException("contact null");
        String id = contact.getContactId();
        if (contacts.containsKey(id)) throw new IllegalArgumentException("duplicate id");
        contacts.put(id, contact);
    }

    public void deleteContact(String contactId) {
        if (contactId == null) throw new IllegalArgumentException("contactId null");
        contacts.remove(contactId);
    }

    public void updateFirstName(String contactId, String firstName) {
        Contact c = getExisting(contactId);
        c.setFirstName(firstName);
    }
    public void updateLastName(String contactId, String lastName) {
        Contact c = getExisting(contactId);
        c.setLastName(lastName);
    }
    public void updatePhone(String contactId, String phone) {
        Contact c = getExisting(contactId);
        c.setPhone(phone);
    }
    public void updateAddress(String contactId, String address) {
        Contact c = getExisting(contactId);
        c.setAddress(address);
    }

    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    private Contact getExisting(String contactId) {
        if (contactId == null) throw new IllegalArgumentException("contactId null");
        Contact c = contacts.get(contactId);
        if (c == null) throw new IllegalArgumentException("contact not found");
        return c;
    }
}
