import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void createValidTask() {
        Task t = new Task("t1", "Name", "Description");
        assertEquals("t1", t.getTaskId());
        assertEquals("Name", t.getName());
    }

    @Test
    public void invalidIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345678901", "Name", "Desc"));
    }

    @Test
    public void nullName() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("id", null, "Desc"));
    }

    @Test
    public void nameTooLong() {
        String longName = "abcdefghijklmnopqrstu"; // 21 chars
        assertThrows(IllegalArgumentException.class, () ->
            new Task("id", longName, "Desc"));
    }

    @Test
    public void updateFieldsValid() {
        Task t = new Task("id2", "N", "D");
        t.setName("New");
        t.setDescription("New desc");
        assertEquals("New", t.getName());
        assertEquals("New desc", t.getDescription());
    }

    @Test
    public void updateWithInvalidDescription() {
        Task t = new Task("id3", "N", "D");
        String longDesc = "x".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(longDesc));
    }
}
