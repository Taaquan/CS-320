import java.util.Objects;

public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validateId(contactId);
        validateFirstName(firstName);
        validateLastName(lastName);
        validatePhone(phone);
        validateAddress(address);

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // validations
    private void validateId(String id) {
        if (id == null || id.length() > 10) throw new IllegalArgumentException("Invalid contactId");
    }
    private void validateFirstName(String v) {
        if (v == null || v.length() > 10) throw new IllegalArgumentException("Invalid firstName");
    }
    private void validateLastName(String v) {
        if (v == null || v.length() > 10) throw new IllegalArgumentException("Invalid lastName");
    }
    private void validatePhone(String v) {
        if (v == null || !v.matches("\\d{10}")) throw new IllegalArgumentException("Invalid phone");
    }
    private void validateAddress(String v) {
        if (v == null || v.length() > 30) throw new IllegalArgumentException("Invalid address");
    }

    // getters
    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    // setters only for updatable fields
    public void setFirstName(String firstName) {
        validateFirstName(firstName);
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        validateLastName(lastName);
        this.lastName = lastName;
    }
    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }
    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Contact contact = (Contact) o;
        return Objects.equals(contactId, contact.contactId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactId);
    }
}
