import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void createValidContact() {
        Contact c = new Contact("id1", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("id1", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    public void invalidIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "John", "Doe", "1234567890", "Addr"));
    }

    @Test
    public void nullFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("id", null, "Doe", "1234567890", "Addr"));
    }

    @Test
    public void invalidPhone() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("id", "John", "Doe", "12345", "Addr"));
    }

    @Test
    public void updateFieldsValid() {
        Contact c = new Contact("a", "F", "L", "0123456789", "Addr");
        c.setFirstName("Jane");
        c.setLastName("Smith");
        c.setPhone("9998887776");
        c.setAddress("New Address");
        assertEquals("Jane", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("9998887776", c.getPhone());
        assertEquals("New Address", c.getAddress());
    }

    @Test
    public void updateWithInvalidPhone() {
        Contact c = new Contact("a2", "F", "L", "0123456789", "Addr");
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("bad"));
    }
}
