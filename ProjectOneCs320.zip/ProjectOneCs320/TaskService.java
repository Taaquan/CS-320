import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) throw new IllegalArgumentException("task null");
        String id = task.getTaskId();
        if (tasks.containsKey(id)) throw new IllegalArgumentException("duplicate id");
        tasks.put(id, task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null) throw new IllegalArgumentException("taskId null");
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        Task t = getExisting(taskId);
        t.setName(name);
    }
    public void updateDescription(String taskId, String description) {
        Task t = getExisting(taskId);
        t.setDescription(description);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    private Task getExisting(String taskId) {
        if (taskId == null) throw new IllegalArgumentException("taskId null");
        Task t = tasks.get(taskId);
        if (t == null) throw new IllegalArgumentException("task not found");
        return t;
    }
}
