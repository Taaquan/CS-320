import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService service;
    private Task t1;

    @BeforeEach
    public void setup() {
        service = new TaskService();
        t1 = new Task("t1", "Name", "Desc");
    }

    @Test
    public void addAndGet() {
        service.addTask(t1);
        assertEquals("Name", service.getTask("t1").getName());
    }

    @Test
    public void addDuplicateThrows() {
        service.addTask(t1);
        Task dup = new Task("t1", "Other", "D");
        assertThrows(IllegalArgumentException.class, () -> service.addTask(dup));
    }

    @Test
    public void deleteTask() {
        service.addTask(t1);
        service.deleteTask("t1");
        assertNull(service.getTask("t1"));
    }

    @Test
    public void updateNameAndDescription() {
        service.addTask(t1);
        service.updateName("t1", "NewName");
        service.updateDescription("t1", "NewDesc");
        Task updated = service.getTask("t1");
        assertEquals("NewName", updated.getName());
        assertEquals("NewDesc", updated.getDescription());
    }

    @Test
    public void updateNonExistingThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.updateName("x", "n"));
    }

    @Test
    public void addNullTaskThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    @Test
    public void deleteNullThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(null));
    }
}
