import java.util.Objects;

public class Task {
    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        validateId(taskId);
        validateName(name);
        validateDescription(description);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    private void validateId(String id) {
        if (id == null || id.length() > 10) throw new IllegalArgumentException("Invalid taskId");
    }
    private void validateName(String v) {
        if (v == null || v.length() > 20) throw new IllegalArgumentException("Invalid name");
    }
    private void validateDescription(String v) {
        if (v == null || v.length() > 50) throw new IllegalArgumentException("Invalid description");
    }

    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    public void setName(String name) {
        validateName(name);
        this.name = name;
    }
    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Task task = (Task) o;
        return Objects.equals(taskId, task.taskId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }
}
